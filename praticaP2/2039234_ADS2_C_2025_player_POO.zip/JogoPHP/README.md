## 📚 Nicollas da Silva Rocha - ADS C 2 - 2025 - 2039234 - Entrega P2 Hierarquia de Classes

### Obersvações:
* Esse projeto foi feito sozinho (sem dupla)

### Dados:

* Nome: Nicollas da Silva Rocha
* Curso: ADS
* Turma: C 2
* RA: 2039234
* Faculdade: Unimar

